/* tofile.dll - wrapper for PEOutputToFile function call

   Mike Strobel
   Oct 15, 1993
*/

#include <windows.h>
#include <string.h>
#include "crpe.h"


int FAR PASCAL LibMain (HANDLE hInstance, WORD wDataSeg, WORD wHeapSize, LPSTR lpszCmdline)
{
  return (1);
}
int CALLBACK WEP (int nParameter)
{
  return (1);
}


int FAR PASCAL ToFile (short FAR job, char FAR *path, short FAR ftype, BOOL FAR numfmt,
		       BOOL FAR datefmt, char FAR *stringdelimiter, char FAR *fielddelimiter)
{
  struct PEPrintFileOptions fileoptions;
  struct PECharSepFileOptions sepfileoptions;
  char temp[2];

  if (ftype == 5) {
    sepfileoptions.StructSize = sizeof (sepfileoptions);
    sepfileoptions.UseReportNumberFmt = numfmt;
    sepfileoptions.UseReportDateFormat = datefmt;

    strncpy (temp, stringdelimiter, 2);
    sepfileoptions.StringDelimiter = temp[0];
    strcpy (sepfileoptions.FieldDelimiter, fielddelimiter);
     
    PEOutputToFile (job, path, PE_FT_CHARSEPARATED, &sepfileoptions);
  }
  else {
    fileoptions.StructSize = sizeof(fileoptions);
    fileoptions.UseReportNumberFmt = numfmt;
    fileoptions.UseReportDateFormat = datefmt;

    PEOutputToFile (job, path, ftype, &fileoptions);
  }

  return (1);
} 
